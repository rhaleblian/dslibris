#include <_ansi.h>

char *
_DEFUN(_user_strerror, (errnum, internal, errptr),
       int errnum _AND
       int internal _AND
       int *errptr)
{
  return 0;
}
